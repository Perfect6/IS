import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { AngularFireModule } from 'angularfire2';
import { AngularFireAuthModule } from 'angularfire2/auth';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { RegisterPage } from '../pages/register/register';
import { LoginPage } from '../pages/login/login';
import { PostLoginPage } from '../pages/post-login/post-login';
import { PostLogiWithoutRegisterPage } from '../pages/post-logi-without-register/post-logi-without-register';
import { SlidePage } from '../pages/slide/slide';

const firebaseIS = {
    apiKey: "AIzaSyATo1nv994kSHJ1gVp4opUQGDXD9hCDMWE",
    authDomain: "ingsoft-8656b.firebaseapp.com",
    databaseURL: "https://ingsoft-8656b.firebaseio.com",
    projectId: "ingsoft-8656b",
    storageBucket: "ingsoft-8656b.appspot.com",
    messagingSenderId: "710701706501"
  };

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    RegisterPage,
    LoginPage,
    PostLoginPage,
    PostLogiWithoutRegisterPage,
    SlidePage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    AngularFireModule.initializeApp(firebaseIS),
    AngularFireAuthModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    RegisterPage,
    LoginPage,
    PostLoginPage,
    PostLogiWithoutRegisterPage,
    SlidePage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
