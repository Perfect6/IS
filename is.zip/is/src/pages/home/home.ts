import { Component } from '@angular/core';
import { NavController, Slide } from 'ionic-angular';

import { RegisterPage } from '../register/register';
import { LoginPage } from '../login/login';
import { PostLoginPage } from '../post-login/post-login';
import { SlidePage } from '../slide/slide';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

  goToRegister(){
  	this.navCtrl.push(RegisterPage);
  }

  goToSignIn(){
  	this.navCtrl.push(LoginPage);
  }

  goToHome(){
    this.navCtrl.push(SlidePage);
  }


}
