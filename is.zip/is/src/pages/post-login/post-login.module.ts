import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PostLoginPage } from './post-login';

@NgModule({
  declarations: [
    PostLoginPage,
  ],
  imports: [
    IonicPageModule.forChild(PostLoginPage),
  ],
})
export class PostLoginPageModule {}
