import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';

import { AngularFireAuth } from 'angularfire2/auth';

import { PostLoginPage } from '../post-login/post-login';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

	@ViewChild('username') user;
	@ViewChild('password') password;

  constructor(public alertCtrl: AlertController, private fire: AngularFireAuth, public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  alert(message1: string, message2: string, message3: string){
  	this.alertCtrl.create({
  		  title: message1,
        subTitle: message2,
        buttons: [message3]
  	}).present();
  }

  signIn(){
  	console.log(this.user.value,this.password.value)
  	this.fire.auth.signInWithEmailAndPassword(this.user.value,this.password.value)
  	.then (data =>{
  		this.alert('Benvenuto!', 'Hai effettuato l\'accesso!', 'CONTINUA');
        this.navCtrl.setRoot(PostLoginPage);
  	})
  	.catch(error =>{
  		this.alert('Errore!', 'Hai inserito dei dati non corretti!', 'RIPROVA');
  	});

  }


}
