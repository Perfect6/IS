import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PostLogiWithoutRegisterPage } from './post-logi-without-register';

@NgModule({
  declarations: [
    PostLogiWithoutRegisterPage,
  ],
  imports: [
    IonicPageModule.forChild(PostLogiWithoutRegisterPage),
  ],
})
export class PostLogiWithoutRegisterPageModule {}
