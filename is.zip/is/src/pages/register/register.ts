import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';

import { AngularFireAuth } from 'angularfire2/auth';

import { LoginPage } from '../login/login';
/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {

@ViewChild('username') user;
@ViewChild('password') password;

  constructor(public alertCtrl: AlertController, private fire : AngularFireAuth, public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterPage');
  }

  registrazione(){

    console.log(this.user.value,this.password.value);

  	this.fire.auth.createUserWithEmailAndPassword(this.user.value,this.password.value)
    .then(data =>{
  		 let alert = this.alertCtrl.create({
          title: 'Complimenti!',
          subTitle: 'Ti sei registrato con successo, adesso puoi accedere usando le tue credenziali!',
          buttons: ['ACCEDI']
        });
        alert.present();
        this.navCtrl.push(LoginPage);
  	})
  	.catch(error =>{
  		let alert = this.alertCtrl.create({
          title: 'Errore!',
          subTitle: 'Immetti una Email verificata!',
          buttons: ['RIPROVA']
        });
        alert.present();
  	});

  }

}
